"""
서울 시간별 날씨 다운로드 (2025-06-01 ~ 2026-06-30)
- 출처: Open-Meteo Historical Weather API (무료, 회원가입·키 불필요)
- 좌표: 기상청 서울 관측소(108, 종로구 송월동) 위치
- 실행: Colab 또는 로컬 파이썬에서 그대로 실행 → seoul_weather_hourly.csv 생성
"""
import pandas as pd
import requests

URL = "https://archive-api.open-meteo.com/v1/archive"
params = {
    "latitude": 37.5714,
    "longitude": 126.9658,
    "start_date": "2025-06-01",
    "end_date": "2026-06-30",
    "hourly": "temperature_2m,precipitation,wind_speed_10m,relative_humidity_2m",
    "wind_speed_unit": "ms",          # 풍속 단위 m/s (기상청과 동일)
    "timezone": "Asia/Seoul",         # 한국 시간 기준
}

res = requests.get(URL, params=params, timeout=60)
res.raise_for_status()
hourly = res.json()["hourly"]

df = pd.DataFrame(hourly).rename(columns={
    "time": "일시",
    "temperature_2m": "기온(°C)",
    "precipitation": "강수량(mm)",
    "wind_speed_10m": "풍속(m/s)",
    "relative_humidity_2m": "습도(%)",
})
df["일시"] = pd.to_datetime(df["일시"])

df.to_csv("seoul_weather_hourly.csv", index=False, encoding="utf-8-sig")
print(df.shape)       # 약 (9480, 5)
print(df.head())
print(df.isna().sum())
